#!/bin/bash
# Copyright 2010-2012 Microsoft Corporation
#           2012-2013 Johns Hopkins University (Author: Daniel Povey)
# Apache 2.0

# This script creates a fully expanded decoding graph (HCLG) that represents
# all the language-model, pronunciation dictionary (lexicon), context-dependency,
# and HMM structure in our model.  The output is a Finite State Transducer
# that has word-ids on the output, and pdf-ids on the input (these are indexes
# that resolve to Gaussian Mixture Models).  
# See
#  http://kaldi.sourceforge.net/graph_recipe_test.html
# (this is compiled from this repository using Doxygen,
# the source for this part is in src/doc/graph_recipe_test.dox)


N=3
P=1
tscale=1.0
loopscale=0.1

reverse=false

for x in `seq 5`; do 
  [ "$1" == "--mono" ] && N=1 && P=0 && shift;
  [ "$1" == "--quinphone" ] && N=5 && P=2 && shift;
  [ "$1" == "--reverse" ] && reverse=true && shift;
  [ "$1" == "--transition-scale" ] && tscale=$2 && shift 2;
  [ "$1" == "--self-loop-scale" ] && loopscale=$2 && shift 2;
done

if [ $# != 4 ]; then
   echo "Usage: utils/mkgraph.sh [options] <lang-dir> <model-dir> <in-g-fst-dir> <graphdir>"
   echo "e.g.: utils/mkgraph.sh data/lang_test exp/tri1/ G.fst exp/tri1/graph"
   echo " Options:"
   echo " --mono          #  For monophone models."
   echo " --quinphone     #  For models with 5-phone context (3 is default)"
   exit 1;
fi

if [ -f path.sh ]; then . ./path.sh; fi

lang=$1
tree=$2/tree
model=$2/final.mdl
dir_g_fst=$3
dir=$4

mkdir -p $dir

# If $lang/tmp/LG.fst does not exist or is older than its sources, make it...
# (note: the [[ ]] brackets make the || type operators work (inside [ ], we
# would have to use -o instead),  -f means file exists, and -ot means older than).

required="$lang/L.fst $lang/phones.txt $lang/words.txt $lang/phones/silence.csl $lang/phones/disambig.int $model $tree"
for f in $required; do
  [ ! -f $f ] && echo "mkgraph.sh: expected $f to exist" && exit 1;
done

mkdir -p $dir/tmp
for gfst in $(ls $dir_g_fst/*.fst); do
	echo "processing $gfst"
	#fstrmepsilon $gfst | fstarcsort --sort_type=ilabel > $dir/tmp/G.fst
	fstarcsort --sort_type=ilabel $gfst > $dir/tmp/G.fst

	# Note: [[ ]] is like [ ] but enables certain extra constructs, e.g. || in 
	# place of -o
	#  fsttablecompose $lang/L.fst $dir/tmp/G.fst | fstdeterminizestar --use-log=true | \
	#    fstminimizeencoded | fstarcsort --sort_type=ilabel > $dir/tmp/LG.fst || exit 1;
	#  fstisstochastic $dir/tmp/LG.fst || echo "[info]: LG not stochastic."

	  fsttablecompose $lang/L.fst $dir/tmp/G.fst | fstarcsort --sort_type=ilabel > $dir/tmp/LG.fst || exit 1;
	  fstisstochastic $dir/tmp/LG.fst || echo "[info]: LG not stochastic."

	clg=$dir/tmp/CLG_${N}_${P}.fst

	  fstcomposecontext --context-size=$N --central-position=$P \
	    $dir/tmp/ilabels_${N}_${P} < $dir/tmp/LG.fst |\
	    fstarcsort --sort_type=ilabel > $clg
	  fstisstochastic $clg  || echo "[info]: CLG not stochastic."

	  if $reverse; then
	    make-h-transducer --reverse=true --push_weights=true \
	      --disambig-syms-out=$dir/disambig_tid.int \
	      --transition-scale=$tscale $dir/tmp/ilabels_${N}_${P} $tree $model \
	      > $dir/Ha.fst  || exit 1;
	  else
	    make-h-transducer  --transition-scale=$tscale $dir/tmp/ilabels_${N}_${P} $tree $model \
	       > $dir/tmp/Ha.fst  || exit 1;
	  fi

	  #fsttablecompose $dir/tmp/Ha.fst $clg | fstdeterminizestar --use-log=true \
	  #  | fstrmepslocal | fstminimizeencoded > $dir/tmp/HCLGa.fst || exit 1;
	  fsttablecompose $dir/tmp/Ha.fst $clg > $dir/tmp/HCLGa.fst || exit 1;

	  fstisstochastic $dir/tmp/HCLGa.fst || echo "HCLG is not stochastic"

	add-self-loops --self-loop-scale=0 --reorder=true \
	   $model < $dir/tmp/HCLGa.fst > $dir/tmp/HCLG.fst || exit 1;

	utt=`basename $gfst | sed 's:\.fst::g'`
	echo "$utt" >> $dir/fsts.1
	fstprint $dir/tmp/HCLG.fst >> $dir/fsts.1
	echo "" >> $dir/fsts.1
done

gzip $dir/fsts.1

#if [[ ! -s $dir/HCLG.fst || $dir/HCLG.fst -ot $dir/HCLGa.fst ]]; then
#  add-self-loops --self-loop-scale=$loopscale --reorder=true \
#    $model < $dir/HCLGa.fst > $dir/HCLG.fst || exit 1;

#  if [ $tscale == 1.0 -a $loopscale == 1.0 ]; then
    # No point doing this test if transition-scale not 1, as it is bound to fail. 
#    fstisstochastic $dir/HCLG.fst || echo "[info]: final HCLG is not stochastic."
#  fi
#fi

# keep a copy of the lexicon and a list of silence phones with HCLG...
# this means we can decode without reference to the $lang directory.

#cp $lang/words.txt $dir/ || exit 1;
#mkdir -p $dir/phones
#cp $lang/phones/word_boundary.* $dir/phones/ 2>/dev/null # might be needed for ctm scoring,
#cp $lang/phones/align_lexicon.* $dir/phones/ 2>/dev/null # might be needed for ctm scoring,
  # but ignore the error if it's not there.

#cp $lang/phones/disambig.{txt,int} $dir/phones/ 2> /dev/null
#cp $lang/phones/silence.csl $dir/phones/ || exit 1;
#cp $lang/phones.txt $dir/ 2> /dev/null # ignore the error if it's not there.

# to make const fst:
# fstconvert --fst_type=const $dir/HCLG.fst $dir/HCLG_c.fst
#am-info --print-args=false $model | grep pdfs | awk '{print $NF}' > $dir/num_pdfs

